﻿namespace SportStore.Models
{
    public enum UserRole
    {
        Guest = 0,
        Client = 1,
        Manager = 2,
        Administrator = 3
    }
}