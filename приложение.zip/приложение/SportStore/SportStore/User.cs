﻿namespace SportStore.Models
{
    public class User
    {
        public string FullName { get; set; }
        public string Email { get; set; }
        public string Password { get; set; }
        public UserRole Role { get; set; }

        public User() { }

        public User(string fullName, string email, string password, UserRole role)
        {
            FullName = fullName;
            Email = email;
            Password = password;
            Role = role;
        }
    }
}