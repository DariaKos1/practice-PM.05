﻿using SportStore.Converters;
using SportStore.Models;
using SportStore.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace SportStore
{
    public partial class CatalogWindow : Window
    {
        private User currentUser;
        private List<Product> allProducts;
        private Product selectedProduct;

        public CatalogWindow(User user)
        {
            InitializeComponent();
            currentUser = user;

            InitializeFilters();
            LoadProducts();
            UpdateUserInfo();

            if (currentUser.Role != UserRole.Administrator)
            {
                btnAddProduct.Visibility = Visibility.Collapsed;
                btnDeleteProduct.Visibility = Visibility.Collapsed;
            }
        }

        private void InitializeFilters()
        {
            cmbManufacturer.Items.Clear();
            cmbManufacturer.Items.Add("Все производители");

            foreach (var manufacturer in DataService.Instance.GetManufacturers())
            {
                cmbManufacturer.Items.Add(manufacturer);
            }
            cmbManufacturer.SelectedIndex = 0;

            cmbSort.SelectedIndex = 0;
        }

        private void UpdateUserInfo()
        {
            txtUserName.Text = currentUser.FullName;

            string roleText;
            if (currentUser.Role == UserRole.Guest)
            {
                roleText = "Гость";
            }
            else if (currentUser.Role == UserRole.Client)
            {
                roleText = "Клиент";
            }
            else if (currentUser.Role == UserRole.Manager)
            {
                roleText = "Менеджер";
            }
            else if (currentUser.Role == UserRole.Administrator)
            {
                roleText = "Администратор";
            }
            else
            {
                roleText = "Неизвестно";
            }

            txtUserRole.Text = "Роль: " + roleText;
            this.Title = "Каталог товаров - " + currentUser.FullName + " (" + roleText + ")";
        }

        private void LoadProducts()
        {
            try
            {
                if (DataService.Instance != null && DataService.Instance.Products != null)
                {
                    allProducts = DataService.Instance.Products.ToList();
                }
                else
                {
                    allProducts = new List<Product>();
                }

                ApplyFilters();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка загрузки товаров: " + ex.Message, "Ошибка",
                              MessageBoxButton.OK, MessageBoxImage.Error);
                allProducts = new List<Product>();
                ApplyFilters();
            }
        }

        private void ApplyFilters()
        {
            try
            {
                if (allProducts == null)
                {
                    allProducts = new List<Product>();
                }

                IEnumerable<Product> filtered = allProducts;

                string search = txtSearch?.Text?.ToLower() ?? "";
                if (!string.IsNullOrEmpty(search))
                {
                    filtered = filtered.Where(p =>
                        (p.Name?.ToLower() ?? "").Contains(search) ||
                        (p.Category?.ToLower() ?? "").Contains(search) ||
                        (p.Manufacturer?.ToLower() ?? "").Contains(search) ||
                        (p.Description?.ToLower() ?? "").Contains(search) ||
                        (p.Supplier?.ToLower() ?? "").Contains(search));
                }

                if (cmbManufacturer != null && cmbManufacturer.SelectedIndex > 0)
                {
                    string manufacturer = cmbManufacturer.SelectedItem?.ToString() ?? "";
                    if (!string.IsNullOrEmpty(manufacturer))
                    {
                        filtered = filtered.Where(p => p.Manufacturer == manufacturer);
                    }
                }

                if (cmbSort != null)
                {
                    if (cmbSort.SelectedIndex == 1) 
                    {
                        filtered = filtered.OrderBy(p => p.Price);
                    }
                    else if (cmbSort.SelectedIndex == 2) 
                    {
                        filtered = filtered.OrderByDescending(p => p.Price);
                    }
                }

                var filteredList = filtered.ToList();
                itemsControlProducts.ItemsSource = filteredList;
                txtStatus.Text = "Показано: " + filteredList.Count + " из " + allProducts.Count + " товаров";
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка фильтрации: " + ex.Message, "Ошибка",
                              MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void txtSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            ApplyFilters();
        }

        private void cmbManufacturer_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ApplyFilters();
        }

        private void cmbSort_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ApplyFilters();
        }

        private void btnAddProduct_Click(object sender, RoutedEventArgs e)
        {
            if (currentUser.Role != UserRole.Administrator)
            {
                MessageBox.Show("Только администратор может добавлять товары",
                              "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (!DataService.Instance.CanOpenEditWindow())
            {
                return;
            }

            EditProductWindow editWindow = new EditProductWindow(null, currentUser);
            editWindow.Owner = this;
            editWindow.Closed += (s, args) =>
            {
                LoadProducts();
            };
            editWindow.ShowDialog();
        }

        private void btnDeleteProduct_Click(object sender, RoutedEventArgs e)
        {
            if (currentUser.Role != UserRole.Administrator)
            {
                MessageBox.Show("Только администратор может удалять товары",
                              "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (selectedProduct == null)
            {
                MessageBox.Show("Выберите товар для удаления",
                              "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            MessageBoxResult result = MessageBox.Show("Вы уверены, что хотите удалить товар: " + selectedProduct.Name + "?",
                                                    "Подтверждение удаления",
                                                    MessageBoxButton.YesNo,
                                                    MessageBoxImage.Question);

            if (result == MessageBoxResult.Yes)
            {
                bool success = DataService.Instance.DeleteProduct(selectedProduct.Id);
                if (success)
                {
                    MessageBox.Show("Товар успешно удален", "Успех",
                                  MessageBoxButton.OK, MessageBoxImage.Information);
                    LoadProducts();
                }
            }
        }

        private void LogoutButton_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }

        private void itemsControlProducts_MouseLeftButtonUp(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            var source = e.OriginalSource as FrameworkElement;
            if (source != null)
            {
                var product = source.DataContext as Product;
                if (product != null)
                {
                    selectedProduct = product;

                    if (currentUser.Role == UserRole.Administrator)
                    {
                        if (!DataService.Instance.CanOpenEditWindow())
                        {
                            return;
                        }

                        EditProductWindow editWindow = new EditProductWindow(product, currentUser);
                        editWindow.Owner = this;
                        editWindow.Closed += (s, args) =>
                        {
                            LoadProducts();
                        };
                        editWindow.ShowDialog();
                    }
                }
            }
        }
    }
}