﻿using SportStore.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows;

namespace SportStore.Services
{
    public class DataService
    {
        private static DataService _instance;
        public static DataService Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new DataService();
                }
                return _instance;
            }
        }

        public List<User> Users { get; private set; }
        public List<Product> Products { get; private set; }
        private bool isEditWindowOpen = false;

        private DataService()
        {
            InitializeUsers();
            InitializeProducts();
        }

        private void InitializeUsers()
        {
            Users = new List<User>
            {
                new User("Пахомова Аиша Анатольевна", "m4ic8j5qgstw@gmail.com", "2L6KZG", UserRole.Administrator),
                new User("Жуков Роман Богданович", "d43zfg9tlsyv@gmail.com", "uzWC67", UserRole.Administrator),
                new User("Киселева Анастасия Максимовна", "8ohgisf6k45w@outlook.com", "8ntwUp", UserRole.Administrator),

                new User("Григорьева Арина Арсентьевна", "hi1brwj46czx@mail.com", "YOyhfR", UserRole.Manager),
                new User("Иванов Лев Михайлович", "fvkbcamhlj52@gmail.com", "RSbvHv", UserRole.Manager),
                new User("Григорьев Лев Давидович", "9qxnce8jwruv@gmail.com", "rwVDh9", UserRole.Manager),

                new User("Поляков Степан Егорович", "dotiex942p1r@gmail.com", "LdNyos", UserRole.Client),
                new User("Леонова Алиса Кирилловна", "n0bmi2h1xral@tutanota.com", "gynQMT", UserRole.Client),
                new User("Яковлев Платон Константинович", "sfm3t278kdvz@yahoo.com", "AtnDjr", UserRole.Client),
                new User("Ковалева Ева Яковлевна", "ilb8rdut0v7e@mail.com", "JlFRCZ", UserRole.Client)
            };
        }

        private void InitializeProducts()
        {
            Products = new List<Product>
            {
                new Product(1, "Боксерская груша X-Match черная", "Спортивный инвентарь", 5, 6, "Боксерская груша для тренировок"),
                new Product(2, "Спортивный мат 100x100x10 см Perfetto Sport № 3 бежевый", "Спортивный инвентарь", 2, 16, "Мат для спортивных занятий"),
                new Product(3, "Шведская стенка ROMANA Next, pastel", "Спортивный инвентарь", 3, 5, "Детская шведская стенка"),
                new Product(4, "Тренажер для прыжков Moby Kids Moby-Jumper со счетчиком", "Спортивный инвентарь", 4, 8, "Тренажер для детских прыжков"),
                new Product(5, "Спортивный костюм playToday (футболка + шорты)", "Одежда", 3, 17, "Спортивный костюм для тренировок"),
                new Product(6, "Набор для хоккея Совтехстром", "Спортивный инвентарь", 4, 7, "Полный набор для хоккея"),
                new Product(7, "Игровой набор Совтехстром Кегли и шары", "Спортивный инвентарь", 2, 9, "Набор для игры в кегли"),
                new Product(8, "Набор Abtoys Бадминтон и теннис", "Спортивный инвентарь", 4, 12, "Набор для бадминтона и тенниса"),
                new Product(9, "Велотренажер двойной DFC B804 dual bike", "Спортивный инвентарь", 5, 5, "Двойной велотренажер"),
                new Product(10, "Тюбинг Nordway, 73 см", "Спортивный инвентарь", 4, 13, "Тюбинг для зимних развлечений"),
                new Product(11, "Клюшка Nordway NDW300 (2019/2020) SR лев. 19 150см", "Спортивный инвентарь", 3, 4, "Хоккейная клюшка"),
                new Product(12, "Лыжный комплект беговые NORDWAY XC Classic, 45-45-45мм, 160см", "Спортивный инвентарь", 4, 23, "Комплект для беговых лыж"),
                new Product(13, "Коньки роликовые Ridex Cricket жен. ABEC 3 кол.:72мм р.:39-42 синий", "Спортивный инвентарь", 4, 7, "Роликовые коньки женские"),
                new Product(14, "Шлем г.л./сноуб. Salomon Grom р.:KS черный (L40836800)", "Спортивный инвентарь", 5, 16, "Защитный шлем"),
                new Product(15, "Мяч волейбольный MIKASA VT370W, для зала, 5-й размер, желтый/синий", "Спортивный инвентарь", 2, 5, "Волейбольный мяч"),
                new Product(16, "Насос Molten HP-18-B для мячей мультиколор", "Спортивный инвентарь", 4, 12, "Насос для мячей"),
                new Product(17, "Ласты Colton CF-02 для плавания р.:33-34 серый/голубой", "Спортивный инвентарь", 3, 6, "Ласты для плавания"),
                new Product(18, "Шапочка для плавания Atemi PU 140 ткань с покрытием желтый", "Спортивный инвентарь", 5, 17, "Шапочка для плавания"),
                new Product(19, "Перчатки для каратэ Green Hill KMС-6083 L красный", "Спортивный инвентарь", 3, 5, "Перчатки для каратэ"),
                new Product(20, "Велосипед SKIF 29 Disc (2021), горный (взрослый), рама: 17\", колеса: 29\", темно-серый", "Спортивный инвентарь", 4, 6, "Горный велосипед"),
                new Product(21, "Штанга Starfit BB-401 30кг пласт. черный", "Спортивный инвентарь", 3, 8, "Штанга для тренировок"),
                new Product(22, "Гиря Starfit ГМБ4 мягкое 4кг синий/оранжевый", "Спортивный инвентарь", 4, 10, "Мягкая гиря"),
                new Product(23, "Коврик Bradex для мягкой йоги дл.:1730мм ш.:610мм т.:3мм серый", "Спортивный инвентарь", 5, 11, "Коврик для йоги"),
                new Product(24, "Ролик для йоги Bradex Туба d=14см ш.:33см оранжевый", "Спортивный инвентарь", 3, 12, "Ролик для йоги"),
                new Product(25, "Защита голени GREEN HILL Panther, L, синий/черный", "Спортивный инвентарь", 4, 6, "Защита для голени"),
                new Product(26, "Очки для плавания Atemi N8401 синий", "Спортивный инвентарь", 5, 14, "Очки для плавания"),
                new Product(27, "Мяч футбольный DEMIX 1STLS1JWWW, универсальный, 4-й размер, белый/зеленый", "Спортивный инвентарь", 2, 5, "Футбольный мяч"),
                new Product(28, "Коньки ATEMI AKSK01DXS, раздвижные, прогулочные, унисекс, 27-30, черный/зеленый", "Спортивный инвентарь", 3, 16, "Раздвижные коньки"),
                new Product(29, "Перчатки Starfit SU-125 атлетические S черный", "Спортивный инвентарь", 4, 3, "Атлетические перчатки"),
                new Product(30, "Степ-платформа Starfit SP-204 серый/черный", "Спортивный инвентарь", 3, 15, "Степ-платформа для фитнеса")
            };
        }

        public User Authenticate(string email, string password)
        {
            foreach (var user in Users)
            {
                if (user.Email.ToLower() == email.ToLower() && user.Password == password)
                {
                    return user;
                }
            }
            return null;
        }

        public List<string> GetManufacturers()
        {
            var manufacturers = new List<string>();
            foreach (var product in Products)
            {
                if (!string.IsNullOrEmpty(product.Manufacturer) && !manufacturers.Contains(product.Manufacturer))
                {
                    manufacturers.Add(product.Manufacturer);
                }
            }
            manufacturers.Sort();
            return manufacturers;
        }

        public List<string> GetCategories()
        {
            var categories = new List<string>();
            foreach (var product in Products)
            {
                if (!string.IsNullOrEmpty(product.Category) && !categories.Contains(product.Category))
                {
                    categories.Add(product.Category);
                }
            }
            categories.Sort();
            return categories;
        }

        public void AddProduct(Product product)
        {
            try
            {
                if (Products.Count > 0)
                {
                    product.Id = Products.Max(p => p.Id) + 1;
                }
                else
                {
                    product.Id = 1;
                }
                Products.Add(product);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка добавления товара: " + ex.Message, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        public void UpdateProduct(Product product)
        {
            try
            {
                for (int i = 0; i < Products.Count; i++)
                {
                    if (Products[i].Id == product.Id)
                    {
                        Products[i] = product;
                        break;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка обновления товара: " + ex.Message, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        public bool DeleteProduct(int id)
        {
            try
            {
                Product productToDelete = null;
                foreach (var product in Products)
                {
                    if (product.Id == id)
                    {
                        productToDelete = product;
                        break;
                    }
                }

                if (productToDelete == null)
                {
                    MessageBox.Show("Товар не найден", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    return false;
                }

                if (productToDelete.IsInOrder)
                {
                    MessageBox.Show("Товар присутствует в заказе и не может быть удален", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    return false;
                }

                if (productToDelete.HasRelatedProducts)
                {
                    bool anyRelatedInOrder = false;
                    foreach (var product in Products)
                    {
                        if (product.Id != id && product.IsInOrder)
                        {
                            anyRelatedInOrder = true;
                            break;
                        }
                    }
                    if (anyRelatedInOrder)
                    {
                        MessageBox.Show("Связанные товары находятся в заказе", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                        return false;
                    }
                }

                Products.Remove(productToDelete);
                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка удаления товара: " + ex.Message, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }
        }

        public bool CanOpenEditWindow()
        {
            if (isEditWindowOpen)
            {
                MessageBox.Show("Закройте текущее окно редактирования", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return false;
            }
            isEditWindowOpen = true;
            return true;
        }

        public void CloseEditWindow()
        {
            isEditWindowOpen = false;
        }
    }
}