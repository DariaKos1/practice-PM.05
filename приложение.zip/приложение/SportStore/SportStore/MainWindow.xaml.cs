﻿using SportStore.Models;
using SportStore.Services;
using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace SportStore
{
    public partial class MainWindow : Window
    {
        private string currentCaptcha = "";
        private int failedAttempts = 0;
        private bool isBlocked = false;
        private DispatcherTimer blockTimer;
        private Random random = new Random();

        public MainWindow()
        {
            InitializeComponent();
            InitializeTimer();
        }

        private void InitializeTimer()
        {
            blockTimer = new DispatcherTimer();
            blockTimer.Interval = TimeSpan.FromSeconds(1);
            blockTimer.Tick += BlockTimer_Tick;
        }

        private void LoginButton_Click(object sender, RoutedEventArgs e)
        {
            if (isBlocked)
            {
                txtStatus.Text = "Система заблокирована. Ожидайте...";
                return;
            }

            string email = txtEmail.Text.Trim();
            string password = txtPassword.Password;

            if (string.IsNullOrEmpty(email))
            {
                txtStatus.Text = "Введите логин";
                txtEmail.Focus();
                return;
            }

            if (string.IsNullOrEmpty(password))
            {
                txtStatus.Text = "Введите пароль";
                txtPassword.Focus();
                return;
            }

            if (failedAttempts >= 1)
            {
                string captchaInput = txtCaptcha.Text.Trim();
                if (string.IsNullOrEmpty(captchaInput))
                {
                    txtStatus.Text = "Введите CAPTCHA";
                    txtCaptcha.Focus();
                    return;
                }

                if (captchaInput.ToUpper() != currentCaptcha.ToUpper())
                {
                    txtStatus.Text = "Неверная CAPTCHA";
                    GenerateCaptcha();
                    txtCaptcha.Clear();
                    txtCaptcha.Focus();
                    return;
                }
            }

            User user = DataService.Instance.Authenticate(email, password);

            if (user != null)
            {
                failedAttempts = 0;
                ShowCaptcha(false);
                txtStatus.Text = "";

                CatalogWindow catalogWindow = new CatalogWindow(user);
                catalogWindow.Show();
                this.Close();
            }
            else
            {
                failedAttempts++;

                if (failedAttempts == 1)
                {
                    txtStatus.Text = "Неверный логин или пароль. Введите CAPTCHA.";
                    ShowCaptcha(true);
                    GenerateCaptcha();
                    txtCaptcha.Focus();
                }
                else if (failedAttempts >= 2)
                {
                    txtStatus.Text = "Неверные данные";
                    BlockSystem();
                }
            }
        }

        private void GuestButton_Click(object sender, RoutedEventArgs e)
        {
            CatalogWindow catalogWindow = new CatalogWindow(new User
            {
                FullName = "Гость",
                Role = UserRole.Guest
            });
            catalogWindow.Show();
            this.Close();
        }

        private void ShowCaptcha(bool show)
        {
            captchaContainer.Visibility = show ? Visibility.Visible : Visibility.Collapsed;
            if (show)
            {
                GenerateCaptcha();
            }
            else
            {
                txtCaptcha.Text = "";
            }
        }

        private void GenerateCaptcha()
        {
            captchaCanvas.Children.Clear();
            string chars = "BCDEFGHIJKLMNOPQRSTUVWXYZ023456789";
            currentCaptcha = "";

            for (int i = 0; i < 4; i++)
            {
                currentCaptcha += chars[random.Next(chars.Length)];
            }

            double[] xPositions = new double[4];
            double[] yPositions = new double[4];

            for (int i = 0; i < currentCaptcha.Length; i++)
            {
                xPositions[i] = i * 45 + random.Next(-15, 15);
                yPositions[i] = random.Next(10, 40);

                TextBlock text = new TextBlock
                {
                    Text = currentCaptcha[i].ToString(),
                    FontSize = random.Next(24, 32),
                    FontWeight = FontWeights.Bold,
                    Foreground = new SolidColorBrush(Color.FromRgb(
                        (byte)random.Next(50, 150),
                        (byte)random.Next(50, 150),
                        (byte)random.Next(50, 150))),
                    RenderTransformOrigin = new System.Windows.Point(0.5, 0.5)
                };

                RotateTransform rotate = new RotateTransform(random.Next(-45, 45));
                text.RenderTransform = rotate;

                Canvas.SetLeft(text, xPositions[i]);
                Canvas.SetTop(text, yPositions[i]);
                captchaCanvas.Children.Add(text);

                if (random.Next(2) == 0)
                {
                    Line line = new Line
                    {
                        X1 = xPositions[i] - 15,
                        Y1 = yPositions[i] - 15,
                        X2 = xPositions[i] + 25,
                        Y2 = yPositions[i] + 25,
                        Stroke = new SolidColorBrush(Color.FromRgb(
                            (byte)random.Next(100, 200),
                            (byte)random.Next(100, 200),
                            (byte)random.Next(100, 200))),
                        StrokeThickness = 2,
                        Opacity = 0.7
                    };
                    captchaCanvas.Children.Insert(0, line);
                }
            }

            for (int i = 0; i < 10; i++)
            {
                Line line = new Line
                {
                    X1 = random.Next(0, 200),
                    Y1 = random.Next(0, 60),
                    X2 = random.Next(0, 200),
                    Y2 = random.Next(0, 60),
                    Stroke = new SolidColorBrush(Color.FromRgb(
                        (byte)random.Next(150, 200),
                        (byte)random.Next(150, 200),
                        (byte)random.Next(150, 200))),
                    StrokeThickness = random.Next(1, 3)
                };
                captchaCanvas.Children.Add(line);
            }

            for (int i = 0; i < 50; i++)
            {
                Ellipse ellipse = new Ellipse
                {
                    Width = random.Next(1, 3),
                    Height = random.Next(1, 3),
                    Fill = new SolidColorBrush(Color.FromRgb(
                        (byte)random.Next(100, 200),
                        (byte)random.Next(100, 200),
                        (byte)random.Next(100, 200))),
                    Opacity = random.NextDouble() * 0.5
                };
                Canvas.SetLeft(ellipse, random.Next(0, 200));
                Canvas.SetTop(ellipse, random.Next(0, 60));
                captchaCanvas.Children.Add(ellipse);
            }
        }

        private void BlockSystem()
        {
            isBlocked = true;
            btnLogin.IsEnabled = false;
            btnGuest.IsEnabled = false;
            blockedContainer.Visibility = Visibility.Visible;

            int blockTime = 10;
            txtBlockedMessage.Text = "Система заблокирована на " + blockTime + " секунд";

            blockTimer.Tag = blockTime;
            blockTimer.Start();
        }

        private void UnblockSystem()
        {
            isBlocked = false;
            btnLogin.IsEnabled = true;
            btnGuest.IsEnabled = true;
            blockedContainer.Visibility = Visibility.Collapsed;
            txtStatus.Text = "";
            txtCaptcha.Text = "";
            failedAttempts = 0;
            ShowCaptcha(false);
            blockTimer.Stop();
        }

        private void BlockTimer_Tick(object sender, EventArgs e)
        {
            int timeLeft = (int)blockTimer.Tag;
            timeLeft--;

            if (timeLeft <= 0)
            {
                UnblockSystem();
            }
            else
            {
                blockTimer.Tag = timeLeft;
                txtBlockedMessage.Text = "Система заблокирована. Осталось: " + timeLeft + " сек";
            }
        }

        private void RefreshCaptcha_Click(object sender, RoutedEventArgs e)
        {
            GenerateCaptcha();
            txtCaptcha.Clear();
            txtCaptcha.Focus();
        }
    }
}