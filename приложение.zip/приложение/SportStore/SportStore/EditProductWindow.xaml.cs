﻿using Microsoft.Win32;
using SportStore.Models;
using SportStore.Services;
using System;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media.Imaging;

namespace SportStore
{
    public partial class EditProductWindow : Window
    {
        private Product currentProduct;
        private User currentUser;
        private bool isEditMode;
        private string imagePath;

        public EditProductWindow(Product product, User user)
        {
            InitializeComponent();
            currentProduct = product;
            currentUser = user;
            isEditMode = product != null;

            InitializeForm();
            if (isEditMode)
            {
                LoadProductData();
            }

            if (isEditMode)
            {
                txtTitle.Text = "Редактирование товара";
                idContainer.Visibility = Visibility.Visible;
            }
            else
            {
                txtTitle.Text = "Добавление товара";
                idContainer.Visibility = Visibility.Collapsed;
            }
        }

        private void InitializeForm()
        {
            cmbCategory.Items.Clear();
            foreach (var category in DataService.Instance.GetCategories())
            {
                cmbCategory.Items.Add(category);
            }

            if (cmbCategory.Items.Count > 0)
            {
                cmbCategory.SelectedIndex = 0;
            }

            cmbUnit.SelectedIndex = 0;
        }

        private void LoadProductData()
        {
            if (currentProduct == null) return;

            txtId.Text = currentProduct.Id.ToString();
            txtName.Text = currentProduct.Name;

            int categoryIndex = -1;
            for (int i = 0; i < cmbCategory.Items.Count; i++)
            {
                if (cmbCategory.Items[i].ToString() == currentProduct.Category)
                {
                    categoryIndex = i;
                    break;
                }
            }
            if (categoryIndex >= 0)
            {
                cmbCategory.SelectedIndex = categoryIndex;
            }

            txtManufacturer.Text = currentProduct.Manufacturer;
            txtPrice.Text = currentProduct.Price.ToString();
            txtQuantity.Text = currentProduct.Quantity.ToString();

            int unitIndex = -1;
            for (int i = 0; i < cmbUnit.Items.Count; i++)
            {
                if ((cmbUnit.Items[i] as ComboBoxItem)?.Content.ToString() == currentProduct.Unit)
                {
                    unitIndex = i;
                    break;
                }
            }
            if (unitIndex >= 0)
            {
                cmbUnit.SelectedIndex = unitIndex;
            }

            txtSupplier.Text = currentProduct.Supplier;
            txtDiscount.Text = currentProduct.Discount.ToString();
            txtDescription.Text = currentProduct.Description;

            if (!string.IsNullOrEmpty(currentProduct.ImagePath) &&
                currentProduct.ImagePath != "picture.png")
            {
                try
                {
                    imgProduct.Source = new BitmapImage(new Uri(currentProduct.ImagePath));
                    imagePath = currentProduct.ImagePath;
                }
                catch
                {
                    imgProduct.Source = new BitmapImage(new Uri("picture.png"));
                }
            }
        }

        private void btnLoadImage_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog
            {
                Filter = "Изображения (*.jpg; *.jpeg; *.png; *.bmp)|*.jpg; *.jpeg; *.png; *.bmp|Все файлы (*.*)|*.*",
                Title = "Выберите изображение товара"
            };

            if (openFileDialog.ShowDialog() == true)
            {
                try
                {
                    var imageInfo = new FileInfo(openFileDialog.FileName);
                    if (imageInfo.Length > 5 * 1024 * 1024)
                    {
                        MessageBox.Show("Изображение слишком большое. Максимальный размер: 5MB",
                                      "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                        return;
                    }

                    imagePath = openFileDialog.FileName;
                    imgProduct.Source = new BitmapImage(new Uri(imagePath));
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка загрузки изображения: " + ex.Message,
                                  "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        private void btnRemoveImage_Click(object sender, RoutedEventArgs e)
        {
            imagePath = null;
            imgProduct.Source = new BitmapImage(new Uri("picture.png"));
        }

        private bool ValidateInput()
        {
            if (string.IsNullOrWhiteSpace(txtName.Text))
            {
                MessageBox.Show("Введите название товара", "Ошибка",
                              MessageBoxButton.OK, MessageBoxImage.Warning);
                txtName.Focus();
                return false;
            }

            if (cmbCategory.SelectedItem == null)
            {
                MessageBox.Show("Выберите категорию", "Ошибка",
                              MessageBoxButton.OK, MessageBoxImage.Warning);
                cmbCategory.Focus();
                return false;
            }

            if (!decimal.TryParse(txtPrice.Text, out decimal price) || price < 0)
            {
                MessageBox.Show("Введите корректную стоимость (положительное число)", "Ошибка",
                              MessageBoxButton.OK, MessageBoxImage.Warning);
                txtPrice.Focus();
                return false;
            }

            if (!int.TryParse(txtQuantity.Text, out int quantity) || quantity < 0)
            {
                MessageBox.Show("Введите корректное количество (неотрицательное целое число)", "Ошибка",
                              MessageBoxButton.OK, MessageBoxImage.Warning);
                txtQuantity.Focus();
                return false;
            }

            if (!int.TryParse(txtDiscount.Text, out int discount) || discount < 0 || discount > 100)
            {
                MessageBox.Show("Введите корректную скидку (0-100%)", "Ошибка",
                              MessageBoxButton.OK, MessageBoxImage.Warning);
                txtDiscount.Focus();
                return false;
            }

            return true;
        }

        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
            if (!ValidateInput()) return;

            try
            {
                if (isEditMode)
                {
                    currentProduct.Name = txtName.Text;
                    currentProduct.Category = cmbCategory.SelectedItem.ToString();
                    currentProduct.Manufacturer = txtManufacturer.Text;
                    currentProduct.Price = decimal.Parse(txtPrice.Text);
                    currentProduct.Quantity = int.Parse(txtQuantity.Text);
                    currentProduct.Unit = (cmbUnit.SelectedItem as ComboBoxItem)?.Content.ToString() ?? "шт";
                    currentProduct.Supplier = txtSupplier.Text;
                    currentProduct.Discount = int.Parse(txtDiscount.Text);
                    currentProduct.Description = txtDescription.Text;
                    currentProduct.ImagePath = imagePath ?? "picture.png";

                    DataService.Instance.UpdateProduct(currentProduct);
                    MessageBox.Show("Товар успешно обновлен", "Успех",
                                  MessageBoxButton.OK, MessageBoxImage.Information);
                }
                else
                {
                    Product newProduct = new Product
                    {
                        Name = txtName.Text,
                        Category = cmbCategory.SelectedItem.ToString(),
                        Manufacturer = txtManufacturer.Text,
                        Price = decimal.Parse(txtPrice.Text),
                        Quantity = int.Parse(txtQuantity.Text),
                        Unit = (cmbUnit.SelectedItem as ComboBoxItem)?.Content.ToString() ?? "шт",
                        Supplier = txtSupplier.Text,
                        Discount = int.Parse(txtDiscount.Text),
                        Description = txtDescription.Text,
                        ImagePath = imagePath ?? "picture.png"
                    };

                    DataService.Instance.AddProduct(newProduct);
                    MessageBox.Show("Товар успешно добавлен", "Успех",
                                  MessageBoxButton.OK, MessageBoxImage.Information);
                }

                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка сохранения: " + ex.Message, "Ошибка",
                              MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void btnCancel_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        protected override void OnClosed(EventArgs e)
        {
            base.OnClosed(e);
            DataService.Instance.CloseEditWindow();
        }
    }
}