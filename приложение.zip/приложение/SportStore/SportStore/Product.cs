﻿namespace SportStore.Models
{
    public class Product
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Category { get; set; }
        public string Manufacturer { get; set; }
        public decimal Price { get; set; }
        public int Quantity { get; set; }
        public string Unit { get; set; }
        public string Supplier { get; set; }
        public int Discount { get; set; }
        public string Description { get; set; }
        public string ImagePath { get; set; }
        public bool IsInOrder { get; set; }
        public bool HasRelatedProducts { get; set; }

        public Product()
        {
            Unit = "шт";
            Supplier = "Основной поставщик";
            ImagePath = "picture.png";
        }

        public Product(int id, string name, string category, int discount, int quantity, string description)
        {
            Id = id;
            Name = name;
            Category = category;
            Discount = discount;
            Quantity = quantity;
            Description = description;
            Unit = "шт";
            Supplier = "Основной поставщик";
            ImagePath = "picture.png";

            // Генерируем производителя из названия
            if (name.Contains("X-Match")) Manufacturer = "X-Match";
            else if (name.Contains("Perfetto")) Manufacturer = "Perfetto Sport";
            else if (name.Contains("ROMANA")) Manufacturer = "ROMANA";
            else if (name.Contains("Moby Kids")) Manufacturer = "Moby Kids";
            else if (name.Contains("playToday")) Manufacturer = "playToday";
            else if (name.Contains("Совтехстром")) Manufacturer = "Совтехстром";
            else if (name.Contains("Abtoys")) Manufacturer = "Abtoys";
            else if (name.Contains("DFC")) Manufacturer = "DFC";
            else if (name.Contains("Nordway")) Manufacturer = "Nordway";
            else if (name.Contains("Ridex")) Manufacturer = "Ridex";
            else if (name.Contains("Salomon")) Manufacturer = "Salomon";
            else if (name.Contains("MIKASA")) Manufacturer = "MIKASA";
            else if (name.Contains("Molten")) Manufacturer = "Molten";
            else if (name.Contains("Colton")) Manufacturer = "Colton";
            else if (name.Contains("Atemi")) Manufacturer = "Atemi";
            else if (name.Contains("Green Hill")) Manufacturer = "Green Hill";
            else if (name.Contains("SKIF")) Manufacturer = "SKIF";
            else if (name.Contains("Starfit")) Manufacturer = "Starfit";
            else if (name.Contains("Bradex")) Manufacturer = "Bradex";
            else if (name.Contains("DEMIX")) Manufacturer = "DEMIX";
            else Manufacturer = "Неизвестно";

            // Генерируем цену на основе названия
            Price = GeneratePrice(name);
        }

        private decimal GeneratePrice(string name)
        {
            // Базовая цена + случайное значение
            var random = new System.Random(Id);
            int basePrice = 1000;

            if (name.Contains("велосипед") || name.Contains("Велосипед")) basePrice = 35000;
            else if (name.Contains("тренажер") || name.Contains("Тренажер")) basePrice = 40000;
            else if (name.Contains("лыжный") || name.Contains("Лыжный")) basePrice = 5000;
            else if (name.Contains("коньки") || name.Contains("Коньки")) basePrice = 3000;
            else if (name.Contains("шлем") || name.Contains("Шлем")) basePrice = 2000;
            else if (name.Contains("клюшка") || name.Contains("Клюшка")) basePrice = 3000;
            else if (name.Contains("мяч") || name.Contains("Мяч")) basePrice = 1000;
            else if (name.Contains("костюм") || name.Contains("Костюм")) basePrice = 5000;
            else if (name.Contains("груша") || name.Contains("Груша")) basePrice = 7000;

            return basePrice + random.Next(500, 2000);
        }

        public bool IsOutOfStock
        {
            get { return Quantity == 0; }
        }

        public decimal FinalPrice
        {
            get { return Price * (100 - Discount) / 100; }
        }
    }
}